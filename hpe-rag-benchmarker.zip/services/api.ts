import axios from 'axios';
import { API_BASE } from '../constants';

export const getLogs = () => axios.get(`${API_BASE}/logs`);
export const uploadFile = (formData: FormData) => axios.post(`${API_BASE}/upload`, formData);
export const getFiles = () => axios.get(`${API_BASE}/files`);
export const deleteFile = (filename: string) => axios.delete(`${API_BASE}/files/${filename}`);

export const chatWithBot = (query: string, useCache: boolean = true) => 
  axios.post(`${API_BASE}/chat`, { 
    query, 
    use_cache: useCache 
  });

export const clearCache = () => axios.delete(`${API_BASE}/milvus/cache/clear`);
export const getModels = () => axios.get(`${API_BASE}/models`);
export const getConfig = () => axios.get(`${API_BASE}/config`);
export const updateConfig = (configData: any) => axios.post(`${API_BASE}/config`, configData);
