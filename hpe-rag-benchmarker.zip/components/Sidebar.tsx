import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  MessageSquare, 
  FolderOpen, 
  Settings, 
  BarChart2, 
  Activity, 
  Menu,
  X
} from 'lucide-react';

interface SidebarProps {
  collapsed: boolean;
  toggle: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ collapsed, toggle }) => {
  const navItems = [
    { to: "/", icon: <MessageSquare size={20} />, label: "Chat" },
    { to: "/files", icon: <FolderOpen size={20} />, label: "Files" },
    { to: "/benchmark", icon: <BarChart2 size={20} />, label: "Benchmark" },
    { to: "/config", icon: <Settings size={20} />, label: "Configuration" },
    { to: "/stats", icon: <Activity size={20} />, label: "System Logs" },
  ];

  return (
    <div 
      className={`fixed left-0 top-0 h-full bg-hpe-slate text-white transition-all duration-300 z-50 flex flex-col shadow-xl ${
        collapsed ? 'w-20' : 'w-64'
      }`}
    >
      {/* HPE Logo Area - The Green Rectangle */}
      <div className="h-20 bg-hpe-slate flex items-center justify-between px-6 border-b border-gray-700 relative">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="w-10 h-5 bg-hpe-green flex-shrink-0"></div>
          {!collapsed && <span className="text-xl font-bold tracking-tight whitespace-nowrap">Hewlett Packard<br/><span className="font-light text-sm">Enterprise</span></span>}
        </div>
        <button onClick={toggle} className="text-gray-400 hover:text-white transition-colors absolute right-2 top-2 p-2">
            {collapsed ? <Menu size={20} /> : <X size={20}/>}
        </button>
      </div>

      <nav className="flex-1 py-6 space-y-2 px-3">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) => `
              flex items-center gap-4 px-4 py-3 rounded-md transition-all duration-200 group
              ${isActive ? 'bg-hpe-green text-white font-semibold shadow-md' : 'text-gray-300 hover:bg-gray-700 hover:text-white'}
            `}
          >
            {({ isActive }) => (
              <>
                <span className={`${isActive ? 'text-white' : 'text-hpe-green group-hover:text-white'}`}>
                    {item.icon}
                </span>
                {!collapsed && <span className="whitespace-nowrap">{item.label}</span>}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      <div className="p-6 border-t border-gray-700">
         {!collapsed ? (
             <div className="text-xs text-gray-400">
                <p>RAG Benchmarker v1.0</p>
                <p>&copy; 2024 HPE</p>
             </div>
         ) : (
            <div className="w-10 h-1 bg-hpe-green mx-auto"></div>
         )}
      </div>
    </div>
  );
};

export default Sidebar;