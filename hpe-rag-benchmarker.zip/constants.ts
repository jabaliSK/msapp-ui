export const API_BASE = "http://10.25.73.101:8050";

export const HPE_GREEN = "#01A982";
export const HPE_SLATE = "#333333";
