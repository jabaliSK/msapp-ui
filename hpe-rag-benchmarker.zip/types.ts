export interface Timings {
  total_sec: number;
  llm_generation_sec: number;
  retrieval_sec: number;
  embedding_sec: number;
  input_guardrail_sec: number;
  output_guardrail_sec: number;
}

export interface ChatResponseData {
  response: string;
  sources: string[];
  safety_check: string;
  timings: Timings;
}

export interface LogEntry {
  id: number;
  timestamp: string;
  user_query: string;
  status: string;
  model_response: string;
  sources: string[];
  safety_check_result: string;
  total_duration_sec: number;
  llm_generation_sec: number;
  retrieval_sec: number;
  embedding_sec: number;
  input_guardrail_sec: number;
  output_guardrail_sec: number;
  client_latency_sec?: number | string;
}

export interface ConfigState {
  llm: { port: string; model: string };
  embed: { port: string; model: string };
  guard: { port: string; model: string };
  ocr: { port: string; model: string };
  cacheThreshold: number;
  systemPrompt: string;
  llmTemperature: number;
}

export interface BenchmarkResult {
  id: number;
  query: string;
  status: "Success" | "Failed";
  response: string;
  sources: string;
  safety: string;
  serverTotal: number;
  llmTime: number;
  retrievalTime: number;
  embedTime: number;
  inputGuardTime: number;
  outputGuardTime: number;
  clientLatency: string | number;
}
