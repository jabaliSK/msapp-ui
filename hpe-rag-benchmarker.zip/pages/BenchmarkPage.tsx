import React, { useState, useRef } from 'react';
import { chatWithBot } from '../services/api';
import { Upload, Play, Clock, Zap, Download } from 'lucide-react';
import { BenchmarkResult } from '../types';

const BenchmarkPage: React.FC = () => {
  const [questions, setQuestions] = useState<string[]>([]);
  const [results, setResults] = useState<BenchmarkResult[]>([]);
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState({ current: 0, total: 0 });
  const [concurrency, setConcurrency] = useState(1); 

  const progressRef = useRef(0);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const lines = text.split(/\r?\n/).filter(line => line.trim() !== '');
      setQuestions(lines);
      setResults([]); 
      setProgress({ current: 0, total: lines.length });
    };
    reader.readAsText(file);
  };

  const handleDownloadCSV = () => {
    if (results.length === 0) return;

    const headers = [
      "ID", "Query", "Status", "Response", "Sources", "Safety", 
      "Server Total (s)", "LLM Gen (s)", "Retrieval (s)", "Embed (s)", 
      "Input Guard (s)", "Output Guard (s)", "Client Latency (s)"
    ];

    const csvRows = results.map(row => {
      const safeQuery = `"${(row.query || "").replace(/"/g, '""')}"`;
      const safeResponse = `"${(row.response || "").replace(/"/g, '""')}"`;
      const safeSources = `"${(row.sources || "").replace(/"/g, '""')}"`;

      return [
        row.id, safeQuery, row.status, safeResponse, safeSources, row.safety,
        row.serverTotal, row.llmTime, row.retrievalTime, row.embedTime,
        row.inputGuardTime, row.outputGuardTime, row.clientLatency
      ].join(",");
    });

    const csvContent = [headers.join(","), ...csvRows].join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `benchmark_results_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const runBenchmark = async () => {
    if (questions.length === 0) return;
    
    setProcessing(true);
    setResults([]);
    progressRef.current = 0;
    setProgress({ current: 0, total: questions.length });

    let globalIndex = 0;

    const worker = async () => {
      while (true) {
        const i = globalIndex++; 
        if (i >= questions.length) break;

        const query = questions[i];
        const clientStart = performance.now();

        try {
          const response = await chatWithBot(query);
          const clientEnd = performance.now();
          const clientLatency = (clientEnd - clientStart) / 1000;

          const data = response.data;
          
          const row: BenchmarkResult = {
            id: i + 1, 
            query: query,
            status: "Success",
            response: data.response,
            sources: data.sources.join(", "),
            safety: data.safety_check,
            serverTotal: data.timings.total_sec,
            llmTime: data.timings.llm_generation_sec,
            retrievalTime: data.timings.retrieval_sec,
            embedTime: data.timings.embedding_sec,
            inputGuardTime: data.timings.input_guardrail_sec,
            outputGuardTime: data.timings.output_guardrail_sec,
            clientLatency: clientLatency.toFixed(4)
          };

          setResults(prev => {
            const newList = [...prev, row];
            return newList.sort((a, b) => a.id - b.id);
          });

        } catch (error: any) {
          const clientEnd = performance.now();
          const row: BenchmarkResult = {
            id: i + 1,
            query: query,
            status: "Failed",
            response: "Error: " + error.message,
            sources: "-",
            safety: "-",
            serverTotal: 0,
            llmTime: 0,
            retrievalTime: 0,
            embedTime: 0,
            inputGuardTime: 0,
            outputGuardTime: 0,
            clientLatency: ((clientEnd - clientStart) / 1000).toFixed(4)
          };
          
          setResults(prev => {
            const newList = [...prev, row];
            return newList.sort((a, b) => a.id - b.id);
          });
        }

        progressRef.current += 1;
        setProgress({ current: progressRef.current, total: questions.length });
      }
    };

    const threads = Array.from({ length: concurrency }).map(() => worker());
    await Promise.all(threads);
    setProcessing(false);
  };

  return (
    <div className="p-8 max-w-full mx-auto h-screen flex flex-col bg-hpe-gray">
      <div className="flex justify-between items-end mb-6">
        <div>
          <h1 className="text-3xl font-bold text-hpe-slate">Latency Benchmark</h1>
          <p className="text-gray-500 mt-2">Stress test your RAG pipeline and visualize latency breakdowns.</p>
        </div>

        {/* Action Bar */}
        <div className="flex gap-4 items-center">
          
          <div className="flex items-center gap-3 bg-white border border-gray-300 px-4 py-2 rounded-sm shadow-sm">
            <Zap size={18} className="text-hpe-yellow" fill="currentColor" />
            <span className="text-sm text-gray-600 font-bold uppercase tracking-wide">Concurrency:</span>
            <select 
              value={concurrency} 
              onChange={(e) => setConcurrency(Number(e.target.value))}
              disabled={processing}
              className="bg-transparent font-bold text-hpe-slate outline-none cursor-pointer"
            >
              <option value={1}>1</option>
              <option value={2}>2</option>
              <option value={4}>4</option>
              <option value={8}>8</option>
            </select>
          </div>

          <div className="relative">
             <input 
              type="file" 
              accept=".txt" 
              onChange={handleFileUpload}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <button className="flex items-center gap-2 bg-white border border-gray-300 text-hpe-slate px-5 py-2.5 rounded-sm hover:bg-gray-50 shadow-sm font-semibold">
              <Upload size={18} />
              <span>{questions.length > 0 ? `${questions.length} Questions Loaded` : "Upload Queries (.txt)"}</span>
            </button>
          </div>

          <button 
            onClick={handleDownloadCSV}
            disabled={processing || results.length === 0}
            className="flex items-center gap-2 bg-white border border-gray-300 text-hpe-slate px-5 py-2.5 rounded-sm hover:bg-gray-50 disabled:opacity-50 shadow-sm font-semibold"
            title="Download Results as CSV"
          >
            <Download size={18} />
            <span>Export CSV</span>
          </button>

          <button 
            onClick={runBenchmark}
            disabled={processing || questions.length === 0}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-sm text-white font-bold transition-all shadow-md ${
              processing || questions.length === 0 
                ? 'bg-gray-400 cursor-not-allowed' 
                : 'bg-hpe-green hover:bg-hpe-green-dark'
            }`}
          >
            {processing ? (
              <>Running... {progress.current}/{progress.total}</>
            ) : (
              <><Play size={18} /> Start Benchmark</>
            )}
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      {processing && (
          <div className="w-full bg-gray-200 h-2 mb-6 rounded-full overflow-hidden">
              <div 
                className="bg-hpe-green h-full transition-all duration-300"
                style={{ width: `${(progress.current / progress.total) * 100}%` }}
              ></div>
          </div>
      )}

      {/* Results Table Container */}
      <div className="bg-white rounded-sm shadow-md border border-gray-200 flex-1 overflow-hidden flex flex-col">
        <div className="overflow-auto flex-1">
          <table className="w-full text-sm text-left text-hpe-slate whitespace-nowrap">
            <thead className="text-xs font-bold text-white uppercase bg-hpe-slate sticky top-0 z-10">
              <tr>
                <th className="px-4 py-4">#</th>
                <th className="px-4 py-4">Query</th>
                <th className="px-4 py-4">Status</th>
                <th className="px-4 py-4">Response (Preview)</th>
                <th className="px-4 py-4">Sources</th>
                <th className="px-4 py-4">Safety</th>
                <th className="px-4 py-4 bg-hpe-purple/20 text-hpe-purple">Total (Server)</th>
                <th className="px-4 py-4">LLM Gen</th>
                <th className="px-4 py-4">Retrieval</th>
                <th className="px-4 py-4">Embed</th>
                <th className="px-4 py-4">In Guard</th>
                <th className="px-4 py-4">Out Guard</th>
                <th className="px-4 py-4 bg-hpe-green/20 text-hpe-green-dark">Client Latency</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {results.length === 0 ? (
                <tr>
                  <td colSpan={13} className="px-6 py-32 text-center text-gray-400">
                    <div className="flex flex-col items-center gap-4">
                      <Clock size={48} className="opacity-20" />
                      <p className="text-lg">Ready to start. Upload a question file.</p>
                    </div>
                  </td>
                </tr>
              ) : (
                results.map((row) => (
                  <tr key={row.id} className="hover:bg-gray-50 transition-colors border-b border-gray-100">
                    <td className="px-4 py-3 font-mono text-xs">{row.id}</td>
                    <td className="px-4 py-3 max-w-xs truncate font-medium" title={row.query}>{row.query}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-sm text-xs font-bold ${row.status === "Success" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>
                        {row.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 max-w-xs truncate text-gray-500" title={row.response}>{row.response}</td>
                    <td className="px-4 py-3 max-w-[150px] truncate text-xs text-gray-400" title={row.sources}>{row.sources}</td>
                    <td className="px-4 py-3 text-xs font-semibold">{row.safety}</td>
                    <td className="px-4 py-3 font-mono bg-hpe-purple/5 text-hpe-purple font-bold border-l-2 border-l-hpe-purple">{row.serverTotal}s</td>
                    <td className="px-4 py-3 font-mono text-gray-500">{row.llmTime}s</td>
                    <td className="px-4 py-3 font-mono text-gray-500">{row.retrievalTime}s</td>
                    <td className="px-4 py-3 font-mono text-gray-500">{row.embedTime}s</td>
                    <td className="px-4 py-3 font-mono text-gray-500">{row.inputGuardTime}s</td>
                    <td className="px-4 py-3 font-mono text-gray-500">{row.outputGuardTime}s</td>
                    <td className="px-4 py-3 font-mono bg-hpe-green/5 text-hpe-green-dark font-bold border-l-2 border-l-hpe-green">{row.clientLatency}s</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default BenchmarkPage;
