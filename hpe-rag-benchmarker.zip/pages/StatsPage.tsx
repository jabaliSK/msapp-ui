import React, { useState, useEffect } from 'react';
import { getLogs } from '../services/api';
import { Download, RefreshCcw, Activity } from 'lucide-react';
import { LogEntry } from '../types';

const StatsPage: React.FC = () => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLogs();
  }, []);

  const fetchLogs = async () => {
    setLoading(true);
    try {
      const res = await getLogs();
      setLogs(res.data);
    } catch (err) {
      console.error("Failed to fetch logs", err);
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadCSV = () => {
    if (logs.length === 0) return;

    const headers = [
      "Query", "Status", "Response", "Sources", "Safety", 
      "Total (Server)", "LLM Gen", "Retrieval", "Embed", 
      "In Guard", "Out Guard", "Client Latency"
    ];

    const csvRows = logs.map(row => {
      const safeQuery = `"${(row.user_query || "").replace(/"/g, '""')}"`;
      const safeResponse = `"${(row.model_response || "").replace(/"/g, '""')}"`;
      const safeSources = `"${(row.sources?.join(", ") || "").replace(/"/g, '""')}"`;

      return [
        safeQuery,
        row.status,
        safeResponse,
        safeSources,
        row.safety_check_result,
        row.total_duration_sec,
        row.llm_generation_sec,
        row.retrieval_sec,
        row.embedding_sec,
        row.input_guardrail_sec,
        row.output_guardrail_sec,
        row.client_latency_sec || "N/A"
      ].join(",");
    });

    const csvContent = [headers.join(","), ...csvRows].join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `rag_stats_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusColor = (status: string) => {
    if (status?.includes("Success")) return "text-green-700 bg-green-100 border-green-200";
    if (status?.includes("Safety")) return "text-orange-700 bg-orange-100 border-orange-200";
    return "text-red-700 bg-red-100 border-red-200";
  };

  return (
    <div className="p-8 max-w-full mx-auto h-screen flex flex-col bg-hpe-gray">
      <div className="flex justify-between items-end mb-6">
        <div>
          <h1 className="text-3xl font-bold text-hpe-slate">System Telemetry</h1>
          <p className="text-gray-500 mt-2">Historical transaction logs from PostgreSQL.</p>
        </div>

        <div className="flex gap-4">
          <button 
            onClick={fetchLogs} 
            className="flex items-center gap-2 bg-white border border-gray-300 text-hpe-slate px-5 py-2.5 rounded-sm hover:bg-gray-50 shadow-sm font-semibold transition-colors"
          >
            <RefreshCcw size={18} className={loading ? 'animate-spin' : ''} /> Refresh
          </button>
          
          <button 
            onClick={handleDownloadCSV}
            disabled={logs.length === 0}
            className="flex items-center gap-2 bg-hpe-green text-white px-5 py-2.5 rounded-sm hover:bg-hpe-green-dark disabled:opacity-50 shadow-md font-bold transition-colors"
          >
            <Download size={18} /> Export CSV
          </button>
        </div>
      </div>

      <div className="bg-white rounded-sm shadow-md border border-gray-200 flex-1 overflow-hidden flex flex-col">
        <div className="overflow-auto flex-1">
          <table className="w-full text-sm text-left text-hpe-slate whitespace-nowrap">
            <thead className="text-xs font-bold text-white uppercase bg-hpe-slate sticky top-0 z-10">
              <tr>
                <th className="px-4 py-4">Timestamp</th>
                <th className="px-4 py-4">Query</th>
                <th className="px-4 py-4">Status</th>
                <th className="px-4 py-4">Response</th>
                <th className="px-4 py-4">Sources</th>
                <th className="px-4 py-4">Safety</th>
                {/* Metrics */}
                <th className="px-4 py-4 bg-hpe-purple/20 text-hpe-purple">Total (S)</th>
                <th className="px-4 py-4">LLM</th>
                <th className="px-4 py-4">RAG</th>
                <th className="px-4 py-4">Embed</th>
                <th className="px-4 py-4">In Guard</th>
                <th className="px-4 py-4">Out Guard</th>
                <th className="px-4 py-4 bg-hpe-green/20 text-hpe-green-dark">Client Latency</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading ? (
                <tr><td colSpan={14} className="p-20 text-center text-lg text-gray-400">Loading telemetry data...</td></tr>
              ) : logs.length === 0 ? (
                <tr><td colSpan={14} className="p-20 text-center text-gray-400 flex flex-col items-center gap-2"><Activity size={32}/>No logs recorded yet.</td></tr>
              ) : (
                logs.map((log) => (
                  <tr key={log.id} className="hover:bg-gray-50 transition-colors border-b border-gray-100">
                    <td className="px-4 py-3 text-xs text-gray-500 font-mono">{new Date(log.timestamp).toLocaleTimeString()}</td>
                    <td className="px-4 py-3 max-w-[200px] truncate font-semibold" title={log.user_query}>{log.user_query}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-sm border text-xs font-bold ${getStatusColor(log.status)}`}>{log.status}</span>
                    </td>
                    <td className="px-4 py-3 max-w-[200px] truncate text-gray-500" title={log.model_response}>{log.model_response}</td>
                    <td className="px-4 py-3 max-w-[100px] truncate text-xs text-gray-400 font-medium" title={log.sources?.join(", ")}>{log.sources?.length || 0} Sources</td>
                    <td className="px-4 py-3 text-xs font-semibold">{log.safety_check_result}</td>
                    
                    {/* Metrics */}
                    <td className="px-4 py-3 font-mono bg-hpe-purple/5 text-hpe-purple font-bold border-l-2 border-l-hpe-purple">{log.total_duration_sec}s</td>
                    <td className="px-4 py-3 font-mono text-gray-500">{log.llm_generation_sec}s</td>
                    <td className="px-4 py-3 font-mono text-gray-500">{log.retrieval_sec}s</td>
                    <td className="px-4 py-3 font-mono text-gray-500">{log.embedding_sec}s</td>
                    <td className="px-4 py-3 font-mono text-gray-500">{log.input_guardrail_sec}s</td>
                    <td className="px-4 py-3 font-mono text-gray-500">{log.output_guardrail_sec}s</td>
                    <td className="px-4 py-3 font-mono bg-hpe-green/5 text-hpe-green-dark font-bold border-l-2 border-l-hpe-green">{log.client_latency_sec || "-"}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default StatsPage;
