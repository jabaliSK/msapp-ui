import React, { useState, useRef, useEffect } from 'react';
import { chatWithBot } from '../services/api';
import { Send, Bot, User, Clock, ShieldCheck, Database, AlertTriangle, Zap } from 'lucide-react';
import { ChatResponseData } from '../types';

interface Message {
  role: 'assistant' | 'user';
  text: string;
  sources?: string[];
  timings?: any;
  safety?: string;
}

const ChatPage: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', text: "Hello! I'm ready to answer questions based on your uploaded documents." }
  ]);
  const [input, setInput] = useState("");
  const [useCache, setUseCache] = useState(true);
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userQuery = input;
    setInput("");
    setMessages(prev => [...prev, { role: 'user', text: userQuery }]);
    setLoading(true);

    try {
      const res = await chatWithBot(userQuery, useCache);
      const data: ChatResponseData = res.data;
      setMessages(prev => [...prev, {
        role: 'assistant',
        text: data.response,
        sources: data.sources,
        timings: data.timings,
        safety: data.safety_check
      }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'assistant', text: "Sorry, I encountered an error connecting to the server." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-hpe-gray relative overflow-hidden">
      {/* Header */}
      <div className="bg-white px-8 py-4 shadow-sm border-b border-gray-200 flex justify-between items-center z-10">
        <div>
          <h1 className="text-2xl font-bold text-hpe-slate">RAG Chat Assistant</h1>
          <p className="text-sm text-gray-500">Secure, enterprise-grade document querying</p>
        </div>
        <div className="flex items-center gap-2">
            <label className={`flex items-center gap-2 text-xs font-bold px-4 py-2 rounded-full border-2 transition-all cursor-pointer select-none ${useCache ? 'bg-hpe-green/10 border-hpe-green text-hpe-green' : 'bg-white border-gray-300 text-gray-500 hover:border-gray-400'}`}>
                <input 
                    type="checkbox" 
                    checked={useCache}
                    onChange={(e) => setUseCache(e.target.checked)}
                    className="hidden"
                />
                <Zap size={14} className={useCache ? 'fill-current' : ''} />
                <span>SEMANTIC CACHE {useCache ? 'ON' : 'OFF'}</span>
            </label>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-8 pb-40 space-y-8">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex gap-6 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
            {/* Avatar */}
            <div className={`w-12 h-12 rounded-lg shadow-sm flex items-center justify-center flex-shrink-0 ${msg.role === 'user' ? 'bg-hpe-green text-white' : 'bg-white border border-gray-200 text-hpe-slate'}`}>
              {msg.role === 'user' ? <User size={24} /> : <Bot size={24} />}
            </div>

            {/* Bubble */}
            <div className={`max-w-3xl flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
              <div className={`p-6 rounded-lg shadow-sm text-base leading-relaxed ${
                  msg.role === 'user' 
                  ? 'bg-hpe-green text-white rounded-tr-none' 
                  : 'bg-white border border-gray-200 text-gray-800 rounded-tl-none'
                }`}>
                {msg.text}
              </div>

              {/* Metadata */}
              {msg.role === 'assistant' && (
                <div className="mt-3 animate-fade-in-up">
                  <div className="flex flex-wrap gap-2 items-center">
                    {msg.sources && msg.sources.map((source, i) => (
                      <span key={i} className="inline-flex items-center gap-1 px-2 py-1 bg-white border border-gray-200 text-gray-600 text-xs font-medium rounded-sm shadow-sm">
                        <Database size={12} className="text-hpe-purple" />
                        {source}
                      </span>
                    ))}
                    {msg.safety && (
                        <span className={`inline-flex items-center gap-1 px-2 py-1 text-xs font-bold rounded-sm border ${msg.safety === 'PASSED' ? 'bg-green-50 border-green-200 text-green-700' : 'bg-red-50 border-red-200 text-red-700'}`}>
                        {msg.safety === 'PASSED' ? <ShieldCheck size={12}/> : <AlertTriangle size={12}/>}
                        {msg.safety}
                        </span>
                    )}
                  </div>
                  
                  {msg.timings && (
                    <div className="flex gap-4 mt-2 text-xs text-gray-400 font-mono bg-gray-100/50 px-2 py-1 rounded w-fit">
                      <span className="flex items-center gap-1"><Clock size={12}/> Total: {msg.timings.total_sec}s</span>
                      <span className="text-gray-300">|</span>
                      <span>LLM: {msg.timings.llm_generation_sec}s</span>
                      <span className="text-gray-300">|</span>
                      <span>RAG: {msg.timings.retrieval_sec}s</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex gap-6">
            <div className="w-12 h-12 rounded-lg bg-white border border-gray-200 flex items-center justify-center shadow-sm">
              <Bot size={24} className="text-hpe-slate animate-pulse" />
            </div>
            <div className="bg-white border border-gray-200 p-6 rounded-lg rounded-tl-none shadow-sm flex items-center gap-2">
              <span className="w-2 h-2 bg-hpe-green rounded-full animate-bounce"></span>
              <span className="w-2 h-2 bg-hpe-green rounded-full animate-bounce delay-100"></span>
              <span className="w-2 h-2 bg-hpe-green rounded-full animate-bounce delay-200"></span>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input Area */}
      <div className="absolute bottom-0 left-0 w-full bg-white/90 backdrop-blur-md border-t border-gray-200 z-20">
        <div className="max-w-5xl mx-auto p-6">
            <form onSubmit={handleSend} className="relative shadow-lg rounded-lg">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Type your query here..."
                    className="w-full pl-6 pr-16 py-4 bg-white border-2 border-gray-200 rounded-lg focus:outline-none focus:border-hpe-green text-gray-700 placeholder-gray-400 transition-colors"
                />
                <button 
                    type="submit" 
                    disabled={!input.trim() || loading}
                    className="absolute right-2 top-2 bottom-2 px-4 bg-hpe-green text-white rounded hover:bg-hpe-green-dark transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                >
                    <Send size={20} />
                </button>
            </form>
            <div className="text-center mt-2">
                <p className="text-xs text-gray-400">AI responses can be inaccurate. Please verify critical information.</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ChatPage;
