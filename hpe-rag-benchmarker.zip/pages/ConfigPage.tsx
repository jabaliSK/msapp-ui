import React, { useState, useEffect } from 'react';
import { getModels, getConfig, updateConfig, clearCache } from '../services/api'; 
import { RefreshCw, Server, CheckCircle, XCircle, Trash2, ShieldAlert, Save, MessageSquare, Check, AlertTriangle, Thermometer } from 'lucide-react';
import { ConfigState } from '../types';

const ROLE_MAPPING = [
    { label: "LLM Generation", key: "llm" },
    { label: "Embedding", key: "embed" },
    { label: "Guardrail", key: "guard" },
    { label: "OCR (Vision)", key: "ocr" }
] as const;

const ConfigPage: React.FC = () => {
  const [activePorts, setActivePorts] = useState<any[]>([]);
  const [scanning, setScanning] = useState(false);
  const [clearingCache, setClearingCache] = useState(false);
  const [saving, setSaving] = useState(false);
  
  const [toast, setToast] = useState({ show: false, message: '', type: 'success' });

  const [config, setConfig] = useState<ConfigState>({
    llm: { port: "", model: "" },
    embed: { port: "", model: "" },
    guard: { port: "", model: "" },
    ocr: { port: "", model: "" },
    cacheThreshold: 0.92,
    systemPrompt: "You are a helpful assistant.",
    llmTemperature: 0.1
  });

  const showToast = (message: string, type = 'success') => {
    setToast({ show: true, message, type });
    setTimeout(() => setToast(prev => ({ ...prev, show: false })), 3000);
  };

  const initializePage = async () => {
    setScanning(true);
    try {
      const [modelsRes, currentConfigRes] = await Promise.all([
          getModels(),
          getConfig().catch(() => ({ data: null }))
      ]);

      const rawModels = modelsRes.data || {};
      const discoveredPorts = Object.entries(rawModels)
        .filter(([model]) => model !== "No Model Found")
        .map(([model, port]) => ({ port: port, models: [{ id: model }] }));
      
      setActivePorts(discoveredPorts);

      if (currentConfigRes && currentConfigRes.data) {
          const s = currentConfigRes.data;
          setConfig(prev => ({
              ...prev,
              llm: { port: s.llm_port, model: s.llm_model_id },
              embed: { port: s.embed_port, model: s.embed_model_id },
              guard: { port: s.guard_port, model: s.guard_model_id },
              ocr: { port: s.vl_port, model: s.vl_model_id },
              cacheThreshold: s.cache_threshold || 0.92,
              systemPrompt: s.system_prompt || prev.systemPrompt,
              llmTemperature: s.llm_temperature !== undefined ? s.llm_temperature : 0.1
          }));
      }
    } catch (err) {
      console.error("Failed to load config:", err);
      showToast("Failed to load configuration.", "error");
    } finally {
      setScanning(false);
    }
  };

  useEffect(() => { initializePage(); }, []);

  const handleAssign = (roleKey: keyof ConfigState, port: string, modelId: string) => {
    // @ts-ignore
    setConfig(prev => ({ ...prev, [roleKey]: { port, model: modelId } }));
  };

  const handleSaveConfig = async () => {
    setSaving(true);
    const payload = {
        llm_port: parseInt(config.llm.port) || 8100,
        llm_model_id: config.llm.model || "Qwen/Qwen3-8B",
        llm_temperature: parseFloat(config.llmTemperature.toString()),

        embed_port: parseInt(config.embed.port) || 8002,
        embed_model_id: config.embed.model || "Qwen/Qwen3-Embedding-0.6B",

        guard_port: parseInt(config.guard.port) || 8001,
        guard_model_id: config.guard.model || "Qwen/Qwen3Guard-Gen-0.6B",

        vl_port: parseInt(config.ocr.port) || 8003,
        vl_model_id: config.ocr.model || "Qwen/Qwen3-VL-8B-Instruct-FP8",

        cache_threshold: parseFloat(config.cacheThreshold.toString()),
        system_prompt: config.systemPrompt
    };

    try {
        await updateConfig(payload);
        showToast("Configuration saved & Models re-bound!");
    } catch (err: any) {
        showToast("Failed to save config: " + err.message, "error");
    } finally {
        setSaving(false);
    }
  };

  const handleClearCache = async () => {
    if (!window.confirm("Are you sure? This will wipe the semantic search cache.")) return;
    setClearingCache(true);
    try {
      await clearCache();
      showToast("Semantic Cache Cleared Successfully!");
    } catch (err: any) {
      showToast("Failed to clear cache: " + err.message, "error");
    } finally {
      setClearingCache(false);
    }
  };

  return (
    <div className="p-8 max-w-6xl mx-auto relative h-screen overflow-y-auto">
      {/* Toast Notification */}
      {toast.show && (
        <div className={`fixed bottom-8 right-8 z-50 px-6 py-4 rounded-sm shadow-xl flex items-center gap-4 transition-all duration-300 border-l-8 ${
            toast.type === 'success' ? 'bg-white border-hpe-green text-hpe-slate' : 'bg-white border-red-500 text-hpe-slate'
        }`}>
            {toast.type === 'success' ? <Check size={20} className="text-hpe-green" /> : <AlertTriangle size={20} className="text-red-500" />}
            <span className="font-bold">{toast.message}</span>
        </div>
      )}

      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-hpe-slate">Model Orchestration</h1>
          <p className="text-gray-500 mt-2">Discover, assign, and tune your local model topology.</p>
        </div>
        <div className="flex gap-3">
            <button 
                onClick={initializePage}
                disabled={scanning}
                className="flex items-center gap-2 bg-white border border-gray-300 px-5 py-2.5 rounded-sm hover:bg-gray-50 transition-colors shadow-sm disabled:opacity-50 font-semibold text-hpe-slate"
            >
                <RefreshCw size={18} className={scanning ? 'animate-spin' : ''} />
                {scanning ? 'Scanning...' : 'Scan Ports'}
            </button>
            <button 
                onClick={handleSaveConfig} 
                disabled={saving || scanning} 
                className="flex items-center gap-2 bg-hpe-green text-white px-6 py-2.5 rounded-sm hover:bg-hpe-green-dark transition-colors shadow-sm disabled:opacity-50 font-bold"
            >
                <Save size={18} />
                {saving ? 'Applying...' : 'Apply Topology'}
            </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
        {activePorts.length === 0 && !scanning && <div className="col-span-full text-center py-12 bg-white border border-dashed border-gray-300 rounded-sm text-gray-500">No active model servers detected. Check your backend.</div>}
        {activePorts.map((node) => (
          <div key={node.port} className="bg-white p-6 rounded-sm border-l-4 border-hpe-green shadow-md flex flex-col gap-3 relative overflow-hidden group hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between z-10">
                <div className="flex items-center gap-2">
                    <Server size={24} className="text-hpe-green" />
                    <span className="font-mono font-bold text-xl text-hpe-slate">:{node.port}</span>
                </div>
                <div className="w-2 h-2 rounded-full bg-hpe-green animate-pulse"></div>
            </div>
            <div className="z-10 mt-2">
                <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Active Model</span>
                <ul className="mt-1 text-sm font-semibold text-hpe-slate">
                    {node.models.map((m: any) => <li key={m.id} className="truncate" title={m.id}>{m.id}</li>)}
                </ul>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-sm shadow-md border border-gray-200 overflow-hidden mb-8">
        <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
            <h3 className="font-bold text-hpe-slate text-lg">Role Assignment</h3>
        </div>
        <div className="divide-y divide-gray-100">
          {ROLE_MAPPING.map((roleObj) => (
            <div key={roleObj.key} className="p-6 flex items-center justify-between hover:bg-gray-50/50 transition-colors">
              <div className="w-1/3">
                  <h4 className="font-bold text-hpe-slate text-base">{roleObj.label}</h4>
                  <p className="text-sm text-gray-500 mt-1">Select the active port handling this workload.</p>
              </div>
              <div className="flex gap-4 w-2/3 items-center">
                <div className="relative flex-1">
                    <select 
                        // @ts-ignore
                        value={config[roleObj.key].port || ""}
                        onChange={(e) => {
                            const port = e.target.value; 
                            const node = activePorts.find(p => p.port.toString() === port);
                            // @ts-ignore
                            handleAssign(roleObj.key, port, node?.models[0]?.id || "");
                        }} 
                        className="w-full bg-white border border-gray-300 text-hpe-slate text-sm rounded-sm p-3 focus:ring-2 focus:ring-hpe-green focus:outline-none"
                    >
                        <option value="">-- Unassigned --</option>
                        {activePorts.map(p => <option key={p.port} value={p.port}>{p.models[0]?.id || `Port ${p.port}`}</option>)}
                    </select>
                </div>
                {/* @ts-ignore */}
                <div className="flex items-center justify-center w-10">{config[roleObj.key].port ? <CheckCircle size={24} className="text-hpe-green" /> : <XCircle size={24} className="text-gray-300" />}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-sm shadow-md border border-gray-200 overflow-hidden mb-8">
        <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
            <h3 className="font-bold text-hpe-slate text-lg">Fine-Tuning</h3>
        </div>
        <div className="divide-y divide-gray-100">
            {/* Cache Threshold */}
            <div className="p-6 flex items-center justify-between">
                <div className="w-1/3">
                    <h4 className="font-bold text-hpe-slate">Semantic Cache Threshold</h4>
                    <p className="text-sm text-gray-500 mt-1">Cosine similarity score (0.5 - 1.0) required for a cache hit.</p>
                </div>
                <div className="w-2/3 flex items-center gap-6">
                    <input type="range" min="0.5" max="1.0" step="0.01" value={config.cacheThreshold} onChange={(e) => setConfig({...config, cacheThreshold: parseFloat(e.target.value)})} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-hpe-green" />
                    <span className="font-mono font-bold text-hpe-slate text-lg w-16 text-right">{config.cacheThreshold}</span>
                </div>
            </div>
            
            {/* Temperature Slider */}
            <div className="p-6 flex items-center justify-between">
                <div className="w-1/3">
                    <h4 className="font-bold text-hpe-slate flex items-center gap-2"><Thermometer size={16} className="text-gray-400"/> LLM Temperature</h4>
                    <p className="text-sm text-gray-500 mt-1">Controls generation randomness (0.0 = Deterministic, 1.0 = Creative).</p>
                </div>
                <div className="w-2/3 flex items-center gap-6">
                    <input type="range" min="0.0" max="1.0" step="0.01" value={config.llmTemperature} onChange={(e) => setConfig({...config, llmTemperature: parseFloat(e.target.value)})} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-hpe-purple" />
                    <span className="font-mono font-bold text-hpe-slate text-lg w-16 text-right">{config.llmTemperature}</span>
                </div>
            </div>

            {/* System Prompt */}
            <div className="p-6 flex items-start justify-between">
                <div className="w-1/3">
                    <h4 className="font-bold text-hpe-slate flex items-center gap-2"><MessageSquare size={16} className="text-gray-400" /> System Prompt</h4>
                    <p className="text-sm text-gray-500 mt-1">Define the persona and global constraints for the LLM.</p>
                </div>
                <div className="w-2/3">
                    <textarea 
                        value={config.systemPrompt} 
                        onChange={(e) => setConfig({...config, systemPrompt: e.target.value})} 
                        className="w-full h-32 p-4 bg-gray-50 border border-gray-300 rounded-sm text-sm font-mono focus:border-hpe-green focus:outline-none focus:bg-white transition-colors" 
                    />
                </div>
            </div>
        </div>
      </div>

      <div className="bg-white rounded-sm shadow-md border border-gray-200 overflow-hidden border-l-8 border-l-hpe-purple">
        <div className="px-6 py-4 border-b border-gray-200 bg-gray-50 flex items-center gap-2">
            <ShieldAlert size={20} className="text-hpe-purple" />
            <h3 className="font-bold text-hpe-slate text-lg">Danger Zone</h3>
        </div>
        <div className="p-6">
          <div className="flex items-center justify-between">
            <div>
                <h4 className="font-bold text-hpe-slate">Clear Semantic Cache</h4>
                <p className="text-sm text-gray-500 mt-1">Permanently removes all cached Q&A vectors. This cannot be undone.</p>
            </div>
            <button onClick={handleClearCache} disabled={clearingCache} className="flex items-center gap-2 bg-white text-red-600 border border-red-200 px-5 py-2.5 rounded-sm hover:bg-red-50 hover:border-red-300 transition-colors disabled:opacity-50 font-semibold">
                <Trash2 size={18} />
                {clearingCache ? 'Clearing...' : 'Flush Cache'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfigPage;
