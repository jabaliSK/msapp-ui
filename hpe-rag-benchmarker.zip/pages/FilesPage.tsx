import React, { useState, useEffect } from 'react';
import { getFiles, uploadFile, deleteFile } from '../services/api';
import { UploadCloud, Trash2, FileText, Check, AlertCircle, FolderOpen } from 'lucide-react';

const FilesPage: React.FC = () => {
  const [files, setFiles] = useState<string[]>([]);
  const [selectedFiles, setSelectedFiles] = useState<Set<string>>(new Set());
  const [uploading, setUploading] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const fetchList = async () => {
    try {
      const res = await getFiles();
      setFiles(res.data);
    } catch (err) {
      console.error("Failed to load files", err);
    }
  };

  useEffect(() => {
    fetchList();
  }, []);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setStatusMsg(null);
    const formData = new FormData();
    formData.append('file', file);

    try {
      await uploadFile(formData);
      setStatusMsg({ type: 'success', text: `Uploaded ${file.name} successfully.` });
      fetchList();
    } catch (err) {
      setStatusMsg({ type: 'error', text: 'Upload failed.' });
    } finally {
      setUploading(false);
    }
  };

  const toggleSelect = (filename: string) => {
    const newSet = new Set(selectedFiles);
    if (newSet.has(filename)) newSet.delete(filename);
    else newSet.add(filename);
    setSelectedFiles(newSet);
  };

  const handleBulkDelete = async () => {
    if (!window.confirm(`Delete ${selectedFiles.size} files?`)) return;
    
    const promises = Array.from(selectedFiles).map((name: string) => deleteFile(name));
    await Promise.all(promises);
    setSelectedFiles(new Set());
    fetchList();
  };

  const handleDeleteOne = async (filename: string) => {
    if (!window.confirm(`Delete ${filename}?`)) return;
    await deleteFile(filename);
    fetchList();
  };

  return (
    <div className="p-8 max-w-7xl mx-auto h-screen flex flex-col bg-hpe-gray">
      <div className="flex justify-between items-end mb-8">
        <div>
          <h1 className="text-3xl font-bold text-hpe-slate">Knowledge Base</h1>
          <p className="text-gray-500 mt-2">Manage your ingestion corpus for Retrieval Augmented Generation.</p>
        </div>
        
        <div className="flex gap-4">
          {selectedFiles.size > 0 && (
            <button 
              onClick={handleBulkDelete}
              className="flex items-center gap-2 bg-white border border-red-200 text-red-600 px-6 py-2.5 rounded-sm hover:bg-red-50 transition-colors font-semibold shadow-sm"
            >
              <Trash2 size={18} /> Delete Selected ({selectedFiles.size})
            </button>
          )}
          
          <label className={`cursor-pointer flex items-center gap-3 bg-hpe-green text-white px-6 py-2.5 rounded-sm hover:bg-hpe-green-dark transition-all shadow-md active:scale-95 ${uploading ? 'opacity-50 pointer-events-none' : ''}`}>
            <UploadCloud size={20} />
            <span className="font-bold">{uploading ? 'Uploading...' : 'Upload Document'}</span>
            <input type="file" className="hidden" onChange={handleUpload} accept=".pdf,.docx,.txt,.jpg,.png,.jpeg" />
          </label>
        </div>
      </div>

      {statusMsg && (
        <div className={`mb-6 p-4 rounded-sm border-l-4 flex items-center gap-3 shadow-sm ${statusMsg.type === 'success' ? 'bg-white border-hpe-green text-hpe-slate' : 'bg-white border-red-500 text-red-700'}`}>
          {statusMsg.type === 'success' ? <Check size={20} className="text-hpe-green"/> : <AlertCircle size={20} className="text-red-500"/>}
          <span className="font-medium">{statusMsg.text}</span>
        </div>
      )}

      <div className="bg-white rounded-sm shadow-sm border border-gray-200 flex-1 overflow-hidden flex flex-col">
        <div className="grid grid-cols-12 bg-gray-100 p-4 border-b border-gray-200 font-bold text-hpe-slate text-sm uppercase tracking-wider">
          <div className="col-span-1 text-center">
             {/* Header Checkbox could go here for select all */}
             #
          </div>
          <div className="col-span-10 pl-4">Filename</div>
          <div className="col-span-1 text-center">Action</div>
        </div>
        
        <div className="overflow-y-auto flex-1 bg-white">
          {files.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-400">
              <FolderOpen size={64} className="mb-4 opacity-20" />
              <p className="text-lg">No documents found in knowledge base.</p>
            </div>
          ) : (
            files.map((file, idx) => (
              <div 
                key={file} 
                className={`grid grid-cols-12 p-4 border-b border-gray-100 items-center transition-colors ${selectedFiles.has(file) ? 'bg-hpe-green/5' : 'hover:bg-gray-50'}`}
              >
                <div className="col-span-1 flex justify-center">
                  <input 
                    type="checkbox" 
                    checked={selectedFiles.has(file)}
                    onChange={() => toggleSelect(file)}
                    className="w-5 h-5 accent-hpe-green cursor-pointer"
                  />
                </div>
                <div className="col-span-10 flex items-center gap-4 pl-4">
                  <div className="w-10 h-10 rounded bg-gray-100 flex items-center justify-center text-hpe-purple">
                    <FileText size={20} />
                  </div>
                  <span className="text-hpe-slate font-semibold truncate">{file}</span>
                </div>
                <div className="col-span-1 flex justify-center">
                  <button onClick={() => handleDeleteOne(file)} className="text-gray-400 hover:text-red-600 p-2 rounded-full hover:bg-red-50 transition-colors">
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
        <div className="bg-gray-50 p-3 border-t border-gray-200 text-xs text-gray-500 text-right">
            Total Files: {files.length}
        </div>
      </div>
    </div>
  );
};

export default FilesPage;